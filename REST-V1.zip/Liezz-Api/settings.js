global.creator = "YanzHost"
global.apikey = ["yanzz", "yanz", "ynz"] // ini apikey nya